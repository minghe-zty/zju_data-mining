import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # 非交互模式设置
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.base import BaseEstimator
from sklearn.metrics import (accuracy_score, precision_score, 
                            recall_score, f1_score, classification_report)
from sklearn.naive_bayes import GaussianNB
from scipy.stats import ttest_rel

# ================= 数据预处理 =================
# 加载数据
df = pd.read_csv('Iris.csv')
X = df.iloc[:, 1:-1].values  # 特征矩阵
y = df.iloc[:, -1].values    # 目标标签

# 数据标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.3, random_state=42)

# ================= 自实现K-means聚类 =================
class MyKMeans:
    def __init__(self, n_clusters=3, max_iter=300, random_state=None):
        self.K = n_clusters
        self.max_iter = max_iter
        self.random_state = random_state
        np.random.seed(random_state)
        
    def fit(self, X):
        # 随机初始化质心
        self.centroids = X[np.random.choice(len(X), self.K, replace=False)]
        
        for _ in range(self.max_iter):
            # 计算每个样本到质心的距离
            distances = np.sqrt(((X - self.centroids[:, np.newaxis])**2).sum(axis=2))
            self.labels = np.argmin(distances, axis=0)
            
            # 更新质心
            new_centroids = np.array([X[self.labels == k].mean(axis=0) 
                                    for k in range(self.K)])
            
            # 收敛检查
            if np.allclose(self.centroids, new_centroids):
                break
            self.centroids = new_centroids
        return self
    
    def predict(self, X):
        distances = np.sqrt(((X - self.centroids[:, np.newaxis])**2).sum(axis=2))
        return np.argmin(distances, axis=0)

# ================= 自实现高斯朴素贝叶斯 =================
class MyGaussianNB(BaseEstimator):
    def __init__(self):
        self.classes_ = None
        self.parameters_ = None
        
    def fit(self, X, y):
        self.classes_ = np.unique(y)
        self.parameters_ = []
        
        for c in self.classes_:
            X_c = X[y == c]
            params = {
                'mean': X_c.mean(axis=0),
                'var': X_c.var(axis=0) + 1e-9,  # 防止零方差
                'prior': X_c.shape[0] / X.shape[0]
            }
            self.parameters_.append(params)
        return self
    
    def predict(self, X):
        posteriors = []
        for x in X:
            class_probs = []
            for param in self.parameters_:
                # 高斯概率密度计算
                exponent = -((x - param['mean'])**2) / (2 * param['var'])
                likelihood = np.exp(exponent) / np.sqrt(2 * np.pi * param['var'])
                log_prob = np.sum(np.log(likelihood)) + np.log(param['prior'])
                class_probs.append(log_prob)
            posteriors.append(np.argmax(class_probs))
        return np.array([self.classes_[p] for p in posteriors])
    
    def score(self, X, y):
        return accuracy_score(y, self.predict(X))

# ================= 实验执行 =================
if __name__ == "__main__":
    # ===== 问题a：聚类可视化 =====
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    
    plt.figure(figsize=(12, 5))
    
    # 自实现K-means
    plt.subplot(121)
    my_kmeans = MyKMeans(n_clusters=3, random_state=42).fit(X_scaled)
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=my_kmeans.labels, cmap='viridis')
    plt.title("My K-means Clustering")
    
    # Sklearn官方实现
    plt.subplot(122)
    sk_kmeans = KMeans(n_clusters=3, random_state=42).fit(X_scaled)
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=sk_kmeans.labels_, cmap='viridis')
    plt.title("Sklearn K-means Clustering")
    
    plt.savefig('clustering_result.png')
    plt.close()

    # ===== 问题b：分类器对比 =====
    # 初始化分类器
    my_clf = MyGaussianNB()
    sk_clf = GaussianNB()
    
    # 训练模型
    my_clf.fit(X_train, y_train)
    sk_clf.fit(X_train, y_train)
    
    # 预测结果
    my_pred = my_clf.predict(X_test)
    sk_pred = sk_clf.predict(X_test)
    
    # 多指标对比
    def print_metrics(y_true, y_pred, name):
        print(f"\n{name} 分类报告：")
        print(classification_report(y_true, y_pred, digits=4))
        print(f"准确率(Accuracy): {accuracy_score(y_true, y_pred):.4f}")
        print(f"宏平均F1(Macro-F1): {f1_score(y_true, y_pred, average='macro'):.4f}")
        print(f"加权F1(Weighted-F1): {f1_score(y_true, y_pred, average='weighted'):.4f}")
        print(f"精确率(Precision): {precision_score(y_true, y_pred, average='macro'):.4f}")
        print(f"召回率(Recall): {recall_score(y_true, y_pred, average='macro'):.4f}\n")
    
    print_metrics(y_test, my_pred, "自实现朴素贝叶斯")
    print_metrics(y_test, sk_pred, "Sklearn朴素贝叶斯")

    # 交叉验证t检验
    my_scores = cross_val_score(my_clf, X_scaled, y, cv=10, scoring='accuracy')
    sk_scores = cross_val_score(sk_clf, X_scaled, y, cv=10, scoring='accuracy')
    t_stat, p_val = ttest_rel(my_scores, sk_scores)
    
    print("\n===== 统计显著性分析 =====")
    print(f"T检验p值: {p_val:.4f}")
    if p_val < 0.05:
        print("结论：两个分类器性能存在显著差异 (p < 0.05)")
    else:
        print("结论：两个分类器性能无显著差异 (p ≥ 0.05)")

    # ===== 问题c：聚类增强分类 =====
    # 在训练集上聚类
    cluster_model = MyKMeans(n_clusters=3, random_state=42).fit(X_train)
    train_clusters = cluster_model.labels
    
    # 为每个簇训练分类器
    cluster_clfs = []
    for k in range(3):
        mask = (train_clusters == k)
        if sum(mask) == 0:  # 处理空簇
            continue
        clf = MyGaussianNB().fit(X_train[mask], y_train[mask])
        cluster_clfs.append(clf)
    
    # 预测测试集
    test_clusters = cluster_model.predict(X_test)
    cluster_preds = []
    for i, x in enumerate(X_test):
        cluster_id = test_clusters[i]
        if cluster_id >= len(cluster_clfs):  # 处理无效簇ID
            pred = np.random.choice(y_train)
        else:
            pred = cluster_clfs[cluster_id].predict([x])[0]
        cluster_preds.append(pred)
    
    print("\n===== 聚类增强分类结果 =====")
    print(f"聚类+分类准确率: {accuracy_score(y_test, cluster_preds):.4f}")
    print(f"原始分类准确率: {accuracy_score(y_test, my_pred):.4f}")
    print("分析：由于鸢尾花数据集本身线性可分性较好，聚类操作可能引入错误划分，导致准确率下降")