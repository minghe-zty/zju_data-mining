import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from collections import Counter
from itertools import combinations
from scipy.stats import chi2_contingency
import os

# -------------------- 1. 数据加载与基本信息 --------------------
df = pd.read_csv('bank.csv', sep=',')
print("数据集维度:", df.shape)
print(df.dtypes, "\n")

# 计算 Imbalance Ratio（多数/少数）
counter = Counter(df['deposit'])
majority = max(counter.values())
minority = min(counter.values())
imbalance_ratio = majority / minority
print("Counts:", counter)
print(f"Imbalance Ratio (多数/少数): {imbalance_ratio:.2f}\n")

# -------------------- 2. 数据预处理 --------------------
# Balance 归一化
scaler = MinMaxScaler()
df['balance_norm'] = scaler.fit_transform(df[['balance']])

# 创建图表输出目录
os.makedirs('figures', exist_ok=True)

# -------------------- 3. 可视化 --------------------
# 3.1 Deposit 订阅分布
counts = df['deposit'].value_counts()
plt.figure()
plt.bar(counts.index, counts.values)
plt.title('Deposit Subscription Distribution')
plt.ylabel('Count')
plt.tight_layout()
plt.savefig('figures/deposit_distribution.png')
plt.close()

# 3.2 年龄分布
plt.figure()
plt.hist(df['age'], bins=20)
plt.title('Age Distribution of Customers')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('figures/age_distribution.png')
plt.close()

# 3.3 职业类别分布
job_counts = df['job'].value_counts()
plt.figure(figsize=(8,4))
plt.barh(job_counts.index, job_counts.values)
plt.title('Job Category Distribution')
plt.xlabel('Count')
plt.tight_layout()
plt.savefig('figures/job_distribution.png')
plt.close()

# 3.4 Balance 归一化前后对比
plt.figure()
plt.hist(df['balance'], bins=30)
plt.title('Balance Before Normalization')
plt.xlabel('Balance')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('figures/balance_before.png')
plt.close()

plt.figure()
plt.hist(df['balance_norm'], bins=30)
plt.title('Balance After Min-Max Normalization')
plt.xlabel('Normalized Balance')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('figures/balance_after.png')
plt.close()

print("可视化图表已保存至 figures/ 目录。\n")

# -------------------- 4. 手写 Apriori 算法 --------------------
def apriori(transactions, min_support):
    item_counts = Counter()
    num_tx = len(transactions)
    min_count = min_support * num_tx
    # 1-项集计数
    for tx in transactions:
        for item in tx:
            item_counts[frozenset([item])] += 1
    # 筛选 1-项集
    freq_itemsets = {1: {item: count for item, count in item_counts.items() if count >= min_count}}
    k = 2
    while True:
        prev = list(freq_itemsets[k-1].keys())
        # 生成候选 k-项集
        candidates = set()
        for i in range(len(prev)):
            for j in range(i+1, len(prev)):
                union = prev[i] | prev[j]
                if len(union) == k:
                    candidates.add(union)
        # 计数并筛选
        cand_counts = Counter()
        for tx in transactions:
            tx_set = set(tx)
            for cand in candidates:
                if cand.issubset(tx_set):
                    cand_counts[cand] += 1
        freq_k = {cand: cnt for cand, cnt in cand_counts.items() if cnt >= min_count}
        if not freq_k:
            break
        freq_itemsets[k] = freq_k
        k += 1
    # 展平所有频繁项集
    flat = {}
    for size, d in freq_itemsets.items(): flat.update(d)
    return flat, num_tx

# -------------------- 5. 手写 FP-Growth 算法 --------------------
class FPNode:
    def __init__(self, item, count, parent):
        self.item = item
        self.count = count
        self.parent = parent
        self.children = {}
        self.link = None

def build_fp_tree(transactions, min_support, num_tx):
    header = Counter()
    for tx in transactions:
        for item in tx: header[item] += 1
    min_count = min_support * num_tx
    header = {it: cnt for it, cnt in header.items() if cnt >= min_count}
    header_table = {it: [cnt, None] for it, cnt in header.items()}
    root = FPNode(None, 1, None)
    for tx in transactions:
        items = [it for it in tx if it in header]
        items.sort(key=lambda x: header[x], reverse=True)
        curr = root
        for it in items:
            if it in curr.children:
                curr.children[it].count += 1
            else:
                node = FPNode(it, 1, curr)
                curr.children[it] = node
                head = header_table[it]
                if head[1] is None:
                    head[1] = node
                else:
                    n = head[1]
                    while n.link: n = n.link
                    n.link = node
            curr = curr.children[it]
    return root, header_table

def ascend(node):
    path = []
    while node and node.parent and node.parent.item:
        node = node.parent
        path.append(node.item)
    return path

def find_prefix_paths(item, header_table):
    paths = []
    node = header_table[item][1]
    while node:
        paths.append((ascend(node), node.count))
        node = node.link
    return paths

def mine_fp(header_table, prefix, min_support, num_tx, freq):
    items = sorted(header_table.items(), key=lambda x: x[1][0])
    for item, (count, _) in items:
        newp = prefix | {item}
        freq[frozenset(newp)] = count
        base = find_prefix_paths(item, header_table)
        cond_tx = []
        for path, cnt in base:
            for _ in range(cnt): cond_tx.append(path)
        if cond_tx:
            root, head = build_fp_tree(cond_tx, min_support, len(cond_tx))
            if head:
                mine_fp(head, newp, min_support, len(cond_tx), freq)

# -------------------- 6. 挖掘并输出 --------------------
categorical = ['job','marital','education','default','housing','loan','contact','month','poutcome','deposit']
transactions = [[f"{col}={row[col]}" for col in categorical] for _, row in df[categorical].iterrows()]
min_support = 0.05

# 6.1 Apriori
fi_apriori, N = apriori(transactions, min_support)
print("Apriori Frequent Itemsets:")
for it, cnt in sorted(fi_apriori.items(), key=lambda x: -x[1])[:10]:
    print(set(it), f"-> count={cnt}, support={cnt/N:.3f}")

# 6.2 FP-Growth
root, head = build_fp_tree(transactions, min_support, len(transactions))
fi_fp = {}
mine_fp(head, set(), min_support, len(transactions), fi_fp)
print("\nFP-Growth Frequent Patterns:")
for it, cnt in sorted(fi_fp.items(), key=lambda x: -x[1])[:10]:
    print(set(it), f"-> count={cnt}, support={cnt/len(transactions):.3f}")

# -------------------- 7. 关联规则生成与评估 --------------------
# 基于 Apriori 结果生成规则
rules = []
for itemset, cnt in fi_apriori.items():
    if len(itemset) < 2: continue
    for r in range(1, len(itemset)):
        for ante in combinations(itemset, r):
            ante = frozenset(ante)
            conse = itemset - ante
            sup_ante = fi_apriori.get(ante, 0)
            sup_con = fi_apriori.get(conse, 0)
            if sup_ante>0 and sup_con>0:
                sup = cnt / N
                conf = cnt / sup_ante
                lift = conf / (sup_con/N)
                lev = sup - (sup_ante/N)*(sup_con/N)
                # chi-square
                a = cnt
                b = sup_ante - cnt
                c = sup_con - cnt
                d = N - a - b - c
                chi2, p, _, _ = chi2_contingency([[a,b],[c,d]], correction=False)
                rules.append((ante, conse, sup, conf, lift, lev, chi2, p))
# 输出 Top 5
rules.sort(key=lambda x: -x[4])
print("\nTop 5 Association Rules:")
for ante, conse, sup, conf, lift, lev, chi2, p in rules[:5]:
    print(f"{set(ante)} -> {set(conse)} | support={sup:.3f}, confidence={conf:.3f}, lift={lift:.3f}, leverage={lev:.3f}, chi2={chi2:.1f}(p={p:.3f})")
