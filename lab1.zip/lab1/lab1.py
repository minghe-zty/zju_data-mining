#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
PCOS Rotterdam 数据处理 + 多视图可视化
------------------------------------
1. 预处理（去重 / 缺失填补 / Winsorize / 离散化 / 标准化 / optional PCA）
2. 批量绘制：Boxplot、Histogram、QQ Plot
3. 全部图片保存到 ./figs 目录
"""

import re
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
from sklearn.preprocessing import StandardScaler, KBinsDiscretizer
from sklearn.decomposition import PCA


# ---------- 辅助：把列名转成安全文件名 ----------
def safe_fname(name: str) -> str:
    """将任意字符串转为安全的文件名（替换空格和非法字符）"""
    return re.sub(r"[\\/:*?\"<>|\s()]+", "_", name)


# ---------- 预处理函数 ----------
def preprocess_pcos(
    input_csv: str,
    output_csv: str = "new_pcos_processed.csv",
    n_bins: int = 4,
    with_pca: bool = True,
) -> pd.DataFrame:
    """
    预处理 PCOS Rotterdam 数据集

    步骤：
      1. 去重
      2. 缺失值 -> 列中位数
      3. Winsorize（1.5×IQR）
      4. 分位数离散化 BMI & Testosterone
      5. 标准化数值特征
      6. 可选 PCA -> 2 维
      7. 保存并返回 DataFrame
    """
    df = pd.read_csv(input_csv).drop_duplicates()
    df = df.fillna(df.median(numeric_only=True))

    numeric_cols = [
        "Age",
        "BMI",
        "Testosterone_Level(ng/dL)",
        "Antral_Follicle_Count",
    ]

    # 3. Winsorize 抑制极端值
    for col in numeric_cols:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        df[col] = df[col].clip(q1 - 1.5 * iqr, q3 + 1.5 * iqr)

    # 4. 离散化
    discretizer = KBinsDiscretizer(
        n_bins=n_bins, encode="ordinal", strategy="quantile"
    )
    df[["BMI_bin", "Testosterone_bin"]] = discretizer.fit_transform(
        df[["BMI", "Testosterone_Level(ng/dL)"]]
    )

    # 5. 标准化
    scaler = StandardScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    # 6. PCA（可选）
    if with_pca:
        pca = PCA(n_components=2, random_state=42)
        df[["PC1", "PC2"]] = pca.fit_transform(df[numeric_cols])

    # 7. 保存
    df.to_csv(output_csv, index=False)
    return df


# ---------- 主程 ----------
if __name__ == "__main__":
    # 1) 预处理
    processed = preprocess_pcos(
        "pcos_rotterdam_balanceado.csv",
        output_csv="new_pcos_processed.csv",
        with_pca=True,
    )
    print(processed.head())
    print("✅ 预处理完成，已保存为 new_pcos_processed.csv")

    # 2) 可视化
    # 用原始数据可视化
    df = pd.read_csv("pcos_rotterdam_balanceado.csv")
    # 用预处理后的数据可视化
    # df = pd.read_csv("new_pcos_processed.csv")
    # 基础数值列
    numeric = [
        "Age",
        "BMI",
        "Testosterone_Level(ng/dL)",
        "Antral_Follicle_Count",
    ]
    # 若存在 PCA 列则追加
    numeric += [c for c in ("PC1", "PC2") if c in df.columns]

    out_dir = Path("figs")
    out_dir.mkdir(exist_ok=True)

    for col in numeric:
        # ——① Boxplot——————————————————————————
        plt.figure()
        plt.boxplot(df[col].dropna())
        plt.title(f"Boxplot of {col}")
        plt.savefig(out_dir / f"{safe_fname(col)}_box.png")
        plt.close()

        # ——② Histogram—————————————————————————
        plt.figure()
        plt.hist(df[col].dropna(), bins=30)
        plt.title(f"Histogram of {col}")
        plt.xlabel(col)
        plt.ylabel("Frequency")
        plt.savefig(out_dir / f"{safe_fname(col)}_hist.png")
        plt.close()

        # ——③ QQ Plot———————————————————————————
        plt.figure()
        stats.probplot(df[col].dropna(), dist="norm", plot=plt)
        plt.title(f"QQ Plot of {col}")
        plt.savefig(out_dir / f"{safe_fname(col)}_qq.png")
        plt.close()

    print("✅ 所有图已保存至 ./figs/")
