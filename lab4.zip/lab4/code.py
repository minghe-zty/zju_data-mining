import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

def init_centers(X: np.ndarray, k: int) -> np.ndarray:
    idx = np.random.choice(X.shape[0], size=k, replace=False)
    return X[idx].copy()

def update_centers(X: np.ndarray, labels: np.ndarray, k: int) -> np.ndarray:
    n_features = X.shape[1]
    centers = np.zeros((k, n_features), dtype=X.dtype)
    for i in range(k):
        members = X[labels == i]
        if len(members) > 0:
            centers[i] = members.mean(axis=0)
    return centers

def assign_labels(X: np.ndarray, centers: np.ndarray) -> np.ndarray:
    dists = np.linalg.norm(
        X[:, np.newaxis, :] 
        - centers[np.newaxis, :, :], 
        axis=2
    )
    return np.argmin(dists, axis=1)

def mini_batch_kmeans(
    X: np.ndarray,
    k: int,
    batch_size: int = 1000,
    n_iters: int = 100
) -> (np.ndarray, np.ndarray):
    centers = init_centers(X, k)
    for _ in range(n_iters):
        batch_idx = np.random.choice(X.shape[0], size=batch_size, replace=False)
        batch = X[batch_idx]
        lbl = assign_labels(batch, centers)
        for i in range(k):
            pts = batch[lbl == i]
            if pts.shape[0] > 0:
                centers[i] = pts.mean(axis=0)

    full_labels = assign_labels(X, centers)
    return centers, full_labels

def kmeans(
    X: np.ndarray,
    k: int,
    max_iters: int = 100,
    tol: float = 1e-4
) -> (np.ndarray, np.ndarray):
    centers = init_centers(X, k)
    for it in range(max_iters):
        labels = assign_labels(X, centers)
        new_centers = update_centers(X, labels, k)
        shift = np.linalg.norm(new_centers - centers)
        if shift < tol:
            print(f"KMeans converged in {it} iters (shift={shift:.6f})")
            break
        centers = new_centers

    labels = assign_labels(X, centers)
    return centers, labels

def inertia(X: np.ndarray, centers: np.ndarray, labels: np.ndarray) -> float:
    assigned_centers = centers[labels] 
    sq_distances = (X - assigned_centers) ** 2
    return float(np.sum(sq_distances))

def silhouette_manual(
    X: np.ndarray,
    labels: np.ndarray,
    sample_size: int = 1000
) -> float:
    n = X.shape[0]
    if n > sample_size:
        idx = np.random.choice(n, sample_size, replace=False)
        Xs = X[idx]
        ls = labels[idx]
    else:
        Xs = X
        ls = labels

    S = []
    for i, x in enumerate(Xs):
        ci = ls[i]
        same = Xs[ls == ci]
        a = np.mean(np.linalg.norm(same - x, axis=1))

        b = np.min([
            np.mean(np.linalg.norm(Xs[ls == c] - x, axis=1))
            for c in set(ls) if c != ci
        ])

        S.append((b - a) / max(a, b))

    return float(np.mean(S))

class IsolationForestCustom:
    def __init__(
        self,
        n_estimators: int = 100,
        max_samples: int = 256,
        max_depth: int = None,
        contamination: float = 0.01,
        random_state: int = None
    ):
        self.n_estimators = n_estimators
        self.max_samples  = max_samples
        self.contamination = contamination
        self.random_state = random_state
        self.max_depth    = max_depth or int(np.ceil(np.log2(max_samples)))
        self._trees = []
        self.threshold_ = None

    def _build_tree(self, X: np.ndarray, depth: int = 0):
        n, m = X.shape
        if depth >= self.max_depth or n <= 1:
            return None
        feature = np.random.randint(0, m)
        lo, hi = X[:, feature].min(), X[:, feature].max()
        if lo == hi:
            return None
        split = np.random.uniform(lo, hi)
        left  = self._build_tree(X[X[:, feature] <= split], depth + 1)
        right = self._build_tree(X[X[:, feature] >  split], depth + 1)
        return (feature, split, left, right)

    def fit(self, X: np.ndarray):
        if self.random_state is not None:
            np.random.seed(self.random_state)

        self._trees = []
        n_samples = X.shape[0]
        for _ in range(self.n_estimators):
            idx = np.random.choice(n_samples, self.max_samples, replace=False)
            sample = X[idx]
            tree = self._build_tree(sample, depth=0)
            self._trees.append(tree)

        scores = self.decision_function(X)
        cutoff = 100 * (1 - self.contamination)
        self.threshold_ = np.percentile(scores, cutoff)
        return self

    def _path_length(self, x: np.ndarray, tree, depth: int = 0) -> float:
        if tree is None:
            return depth
        feature, split, left, right = tree
        if x[feature] <= split:
            return self._path_length(x, left, depth + 1)
        else:
            return self._path_length(x, right, depth + 1)

    def decision_function(self, X: np.ndarray) -> np.ndarray:
        gamma = 0.5772156649
        n = self.max_samples
        c = 2 * (np.log(n - 1) + gamma) - 2 * (n - 1) / n

        scores = []
        for x in X:
            h = np.mean([self._path_length(x, tree, depth=0) for tree in self._trees])
            scores.append(2 ** (-h / c))
        return np.array(scores)

    def predict(self, X: np.ndarray) -> np.ndarray:
        scores = self.decision_function(X)
        return np.where(scores >= self.threshold_, -1, 1)

# 1. 读取原始文件
train = pd.read_csv("train.csv", parse_dates=["TX_DATETIME"])
test  = pd.read_csv("test.csv",  parse_dates=["TX_DATETIME"])
cust  = pd.read_csv("customer.csv")
term  = pd.read_csv("terminal.csv")
# 检查原始缺失值
print("train null values:", train.isnull().sum())
print("test null values:", test.isnull().sum())
print("cust null values:", cust.isnull().sum())
print("term null values:", term.isnull().sum())
print("1 done")
# 2. 合并静态表左连接到主交易表上
def merge_meta(df):
    return df.merge(cust, on="CUSTOMER_ID", how="left") \
             .merge(term, on="TERMINAL_ID", how="left")

train = merge_meta(train)
test  = merge_meta(test)
print(train.head())
print(test.head())
print("2 done")
# 3. 坐标中位数填充
for col in ["x_customer_id","y_customer_id","x_terminal_id","y_terminal_id"]:
    med = pd.concat([train[col], test[col]]).median()
    train[col] = train[col].fillna(med)
    test [col] = test [col].fillna(med)
print("3 done")
# 4. 可用终端数
for df in (train, test):
    df["avail_term_count"] = df["available_terminals"].str.count(",")+1
    df.drop("available_terminals", axis=1, inplace=True)
print("4 done")
# 5. 获取时间特征
for df in (train, test):
    df["hour"]       = df["TX_DATETIME"].dt.hour
    df["weekday"]    = df["TX_DATETIME"].dt.weekday
    df["is_weekend"] = (df["weekday"]>=5).astype(int)
    df["month"]      = df["TX_DATETIME"].dt.month
print("5 done")
# 6. 按小时统计
hour_stats = train.groupby("hour")["TX_AMOUNT"].agg(["mean","std"])\
                  .rename(columns={"mean":"hour_amt_mean","std":"hour_amt_std"})
train = train.join(hour_stats, on="hour")
test  = test.join(hour_stats, on="hour")
print("6 done")
# 7. 地理距离
for df in (train, test):
    df["cust_term_dist"] = np.hypot(
        df["x_customer_id"]-df["x_terminal_id"],
        df["y_customer_id"]-df["y_terminal_id"]
    )
print("7 done")
# 8. 金额比率
for df in (train, test):
    df["amt_to_mean"] = df["TX_AMOUNT"] / (df["mean_amount"]+1e-6)
    df["amt_to_std"]  = (df["TX_AMOUNT"] - df["mean_amount"]) / (df["std_amount"]+1e-6)
    df["log_amount"]  = np.log1p(df["TX_AMOUNT"])
print("8 done")
# 9. 7 天滑窗特征
for df in (train, test):
    df.sort_values(["CUSTOMER_ID","TX_DATETIME"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    # 这里初始化为 0.0，dtype=float
    txn_cnt = pd.Series(0.0, index=df.index, dtype=float)
    txn_amt = pd.Series(0.0, index=df.index, dtype=float)

    for cid, g in df.groupby("CUSTOMER_ID", sort=False):
        cnt = g.rolling("7D", on="TX_DATETIME")["TX_AMOUNT"].count() - 1
        amt = g.rolling("7D", on="TX_DATETIME")["TX_AMOUNT"].sum() - g["TX_AMOUNT"]

        txn_cnt.loc[g.index] = cnt.values
        txn_amt.loc[g.index] = amt.values

    df["txn_cnt_7d"] = txn_cnt
    df["txn_amt_7d"] = txn_amt

print("9 done")
# 10. 定义特征列表
FEATURES = [
    "hour","weekday","is_weekend","month",
    "cust_term_dist",
    "amt_to_mean","amt_to_std","log_amount",
    "hour_amt_mean","hour_amt_std",
    "avail_term_count","nb_terminals",
    "mean_amount","std_amount","mean_nb_tx_per_day",
    "txn_cnt_7d","txn_amt_7d"
]
print("10 done")


from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
import numpy as np
import matplotlib.pyplot as plt

# 11. 聚类 & 可视化 （加速版）

# 11.1 特征矩阵
X = train[FEATURES].values
sample_idx = np.random.choice(len(X), size=20000, replace=False)
X_samp = X[sample_idx]
ks = range(2, 11)
inertias, sil_scores = [], []

for k in ks:
    centers, labels = mini_batch_kmeans(
        X_samp,
        k,
        batch_size=5000,
        n_iters=50
    )
    inertias.append(inertia(X_samp, centers, labels))
    sil_scores.append(silhouette_manual(
        X_samp,
        labels,
        sample_size=5000
    ))

plt.figure()
plt.plot(list(ks), inertias, 'o-')
plt.title('Elbow Method (manual)')
plt.xlabel('Number of clusters k')
plt.ylabel('Inertia (SSE)')
plt.savefig('elbow_manual.png')
plt.close()

plt.figure()
plt.plot(list(ks), sil_scores, 'o-')
plt.title('Silhouette Score (manual)')
plt.xlabel('Number of clusters k')
plt.ylabel('Silhouette Score')
plt.savefig('silhouette_manual.png')
plt.close()
print("11 done")

# 11.3 最终聚类 k=4（举例，用全量数据）
k_opt = 4
centers4, labels4 = kmeans(X, k_opt)
train["cluster"] = labels4


# 11.4 PCA 可视化（全量数据）
X_pca = PCA(n_components=2, random_state=42).fit_transform(X)
plt.figure(figsize=(6,5))
plt.scatter(X_pca[:,0], X_pca[:,1], c=labels4, cmap="tab10", s=5)
plt.title("PCA Projection of Clusters")
plt.xlabel("PC1"); plt.ylabel("PC2")
plt.savefig("pca_clusters.png"); plt.close()

# 11.5 簇中心对比条形图
centers = centers4
x = np.arange(len(FEATURES))
width = 0.8 / k_opt
plt.figure(figsize=(10,5))
for i in range(k_opt):
    plt.bar(x + i*width, centers[i], width=width, label=f"Cluster {i}")
plt.xticks(x + width*(k_opt-1)/2, FEATURES, rotation=90)
plt.title("Cluster Centers Comparison")
plt.legend()
plt.tight_layout()
plt.savefig("cluster_centers.png")
plt.close()

print("导出： elbow.png, silhouette.png, pca_clusters.png, cluster_centers.png")

iso = IsolationForestCustom(contamination=0.01, random_state=42)
iso.fit(train[FEATURES].values)
train["outlier_score"] = iso.decision_function(train[FEATURES].values)
train["is_outlier"]   = (iso.predict(train[FEATURES].values) == -1).astype(int)


# 12. 离群点检测可视化
# 12.1 离群点数目分布
outlier_counts = train['is_outlier'].value_counts().sort_index()
plt.figure()
plt.bar(['Normal', 'Outlier'], outlier_counts)
plt.title('Normal vs Outlier Transaction Counts')
plt.ylabel('Count')
plt.savefig('outlier_counts.png')
plt.close()

# 12.2 PCA 投影高亮离群点
X = train[FEATURES].values
pca = PCA(n_components=2, random_state=42).fit_transform(X)
plt.figure(figsize=(6,5))
plt.scatter(pca[train['is_outlier']==0,0], pca[train['is_outlier']==0,1],
            label='Normal', s=5, alpha=0.5)
plt.scatter(pca[train['is_outlier']==1,0], pca[train['is_outlier']==1,1],
            label='Outlier', s=5, alpha=0.8, marker='x')
plt.title('PCA Projection Highlighting Outliers')
plt.legend()
plt.xlabel('PC1'); plt.ylabel('PC2')
plt.savefig('outlier_pca.png')
plt.close()

